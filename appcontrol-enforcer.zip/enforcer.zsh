#!/bin/zsh
# AppControl enforcer. Runs as a DDM background task from a tamper-proof location.
# Rule: a process may run if Apple signed it, or if its signature matches allowlist.txt.
# Anything else is stopped (mode enforce) or only logged (mode report).
setopt extendedglob
zmodload zsh/zselect

LIST=${0:A:h}/allowlist.txt
log() { /usr/bin/logger -t AppControl "AppControl: $*" }

# Take no action if the list is missing, so a bad deployment can't lock up the Mac.
[[ -r $LIST ]] || { log "ERROR allow list missing: $LIST"; sleep 60; exit 1 }

typeset -A TEAMS CDHASHES
MODE=report
while read -r kind value _; do
  case $kind in
    team)   TEAMS[$value]=1 ;;
    cdhash) CDHASHES[${value:l}]=1 ;;
    mode)   MODE=$value ;;
  esac
done < $LIST
log "START mode=$MODE teams=${#TEAMS} cdhashes=${#CDHASHES}"

field() { print -r -- ${${(M)${(f)1}:#$2=*}[1]#$2=} }

allowed() {   # Checks the running process's signature, not the file on disk
  local pid=$1 info team cdh
  # 1. Apple's own code: macOS and its built-in tools
  /usr/bin/codesign -v --no-strict -R='anchor apple' $pid &>/dev/null && return 0
  info=$(/usr/bin/codesign -dvvv $pid 2>&1)
  # 2. An approved Team ID, on a certificate Apple issued (Developer ID or Mac App Store)
  team=$(field "$info" TeamIdentifier)
  if [[ -n $team && -n ${TEAMS[$team]} ]]; then
    /usr/bin/codesign -v --no-strict -R="anchor apple generic and (certificate leaf[subject.OU] = \"$team\" or certificate leaf[field.1.2.840.113635.100.6.1.9] exists)" $pid &>/dev/null && return 0
  fi
  # 3. An approved CDHash (ad-hoc signed tools, for example Homebrew formulas)
  cdh=$(field "$info" CDHash)
  [[ -n $cdh && -n ${CDHASHES[${cdh:l}]} ]] && return 0
  return 1
}

typeset -A seen now
while true; do
  now=()
  /bin/ps -axo pid=,comm= | while read -r pid exe; do
    now["$pid $exe"]=1
    (( pid > 1 )) || continue
    [[ -n ${seen["$pid $exe"]} ]] && continue     # each process is checked only once
    allowed $pid && continue
    /bin/kill -0 $pid 2>/dev/null || continue     # already exited
    log "DENY mode=$MODE pid=$pid exe=$exe"
    [[ $MODE == enforce ]] && /bin/kill -9 $pid
  done
  seen=( "${(@kv)now}" )
  zselect -t 100                                  # 1 second, without starting a process
done
